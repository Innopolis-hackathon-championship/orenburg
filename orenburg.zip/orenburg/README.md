# Простите нас, мы случайно это чудовище родили.


### Xd team.
Тг бот написат на **aiogram** 

Mini app на **React.js**

Бекенд - франкенштейн из **Django** и **FastAPI**

Докер вроде собрался, но свечку поставить, перед запуском стоит.

    docker compose build
    docker compose up
