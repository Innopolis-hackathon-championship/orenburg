import aiohttp


async def get_orders_data():
    # url = ""
    # headers = {
        
    # }
    # async with aiohttp.ClientSession() as session:
    #     async with session.get(url, ssl=False) as resp:
    #         result = resp.json()
    # return result
    return False
