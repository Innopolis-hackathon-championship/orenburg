#!/usr/bin/env bash

python manage.py runserver --noreload 0.0.0.0:8000
