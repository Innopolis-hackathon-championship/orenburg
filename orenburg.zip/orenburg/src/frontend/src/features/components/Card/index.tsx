/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
import { useState, useEffect } from "react";
import { useShowPopup } from "@vkruglikov/react-telegram-web-app";
import "./Card.scss";

const Card = ({
  name,
  price,
  quant,
  image_url,
  id,
  cartState,
  setCartState,
}: {
  name: string;
  price: number;
  quant: number;
  image_url: "string";
  id: number | string;
  // eslint-disable-next-line @typescript-eslint/ban-types
  setCartState: Function;
  cartState: object;
}) => {
  const showPopup = useShowPopup();

  const [visible, setVisible] = useState<boolean>(true);
  const [counter, setCounter] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(quant);

  useEffect(() => {
    if (counter >= 0) {
      setCartState((prev: object) => {
        return {
          ...prev,
          [id]: {
            count: counter,
            name: name,
            image: image_url,
            price: price,
          },
        };
      });
    }
  }, [counter]);
  console.log(cartState)

  function handleClick() {
    setVisible(false);
    setCounter((prev) => (prev += 1));
    setQuantity((prev) => (prev -= 1));
  }

  useEffect(() => {
    console.log(cartState)
    setCounter(() => {
      if (Object.keys(cartState).length) {
        return cartState.id.count
      } else {
        return 0
      }
    })
  }, [])

  return (
    <div className="card">
      <div className="image">
        {counter ? <div className="product-counter">{counter}</div> : null}
        <img src={'/media/'+image_url} alt="image alt" />
      </div>
      <div className="title">{name}</div>
      <div className="price">Цена: {price}руб.</div>
      <div className="quantity">Остаток: {quantity}</div>
      <div className="button-add">
        {visible === true ? (
          <button onClick={handleClick}>Добавить</button>
        ) : (
          <div className="controls">
            <button
              className="minus"
              onClick={() => {
                setCounter((prev) => {
                  if (prev === 1) {
                    setQuantity((prev) => (prev += 1));
                    setVisible(true);
                  } else {
                    setQuantity((prev) => (prev += 1));
                    return (prev -= 1);
                  }
                  return 0;
                });
              }}
            >
              -
            </button>
            <button
              className="plus"
              onClick={() => {
                setQuantity((prev) => {
                  if (prev === 0) {
                    showPopup({ message: "Больше нет этого товара" });
                    return prev;
                  } else {
                    setCounter((prev) => (prev += 1));
                    return (prev -= 1);
                  }
                });
              }}
            >
              +
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Card;
