import { Link } from "react-router-dom";
import "./Header.scss";

const Header = () => {
  return (
    <header className="header">
      <p className="header-title">
        <p>Буфет</p>
      </p>
      <p className="header-history-link">
        <Link to={"/order/12324"}>Заказ</Link>
      </p>
    </header>
  );
};

export default Header;
