import { WebAppProvider } from "@vkruglikov/react-telegram-web-app";
import { ReactNode } from "react";

const TgProvider = ({ children }: { children: ReactNode }) => {
  return (
    <WebAppProvider
      options={{
        smoothButtonsTransition: true,
      }}
    >
      {children}
    </WebAppProvider>
  );
};

export default TgProvider;
