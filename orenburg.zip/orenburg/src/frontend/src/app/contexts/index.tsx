import { Context } from "./Context";
import { UpdateContext } from "./UpdateContext";
import { Fragment, ReactNode, useState } from "react";
import { useInitData } from "@vkruglikov/react-telegram-web-app";

const ContextProvider = ({ children }: { children: ReactNode }) => {
  const [initDataUnsafe] = useInitData();
  const [userInfo, setUserInfo] = useState<object>(initDataUnsafe);
  const [data, setData] = useState<[]>([]);

  const [cart, setCart] = useState<object>({});

  return (
    <Fragment>
      <Context.Provider value={[userInfo, cart, data]}>
        <UpdateContext.Provider value={[setUserInfo, setCart, setData]}>
          {children}
        </UpdateContext.Provider>
      </Context.Provider>
    </Fragment>
  );
};

export default ContextProvider;

export { Context, UpdateContext };
