import "./index.scss";
import Routing from "pages";
import Router from "./Router/index.tsx";
import TgProvider from "./TgProvider/index.tsx";
import ContextProvider from "./contexts/index.tsx";

const App = () => {
  return (
    <div className="container">
      <TgProvider>
        <ContextProvider>
          <Router>
            <Routing />
          </Router>
        </ContextProvider>
      </TgProvider>
    </div>
  );
};

export default App;
