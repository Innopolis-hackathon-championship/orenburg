import { BackButton } from "@vkruglikov/react-telegram-web-app";
import "./History.scss";
import { useNavigate } from "react-router-dom";

const History = () => {
  const navigate = useNavigate()
  return <main className="history">История
  <BackButton
        onClick={() => {
          navigate('/')
        }}
      />
  </main>;
};

export default History;
