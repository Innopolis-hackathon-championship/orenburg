// eslint-disable-next-line @typescript-eslint/no-unused-vars
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
import "./Landing.scss";
import Card from "features/components/Card";
import { MainButton } from "@vkruglikov/react-telegram-web-app";
import { Context, UpdateContext } from "app/contexts";
import { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {Circles} from 'react-loader-spinner' 

function checkHasNoZero(items) {
  let hasNonZeroCount = false;

  for (const key in items) {
    if (items[key].count !== 0) {
      hasNonZeroCount = true;
      break;
    }
  }

  return hasNonZeroCount;
}

const Landing = () => {
  const [, cart, data] = useContext(Context);
  const [, setCart, setData] = useContext(UpdateContext);
  const [cartState, setCartState] = useState<object>({});
  const navigate = useNavigate();

  useEffect(() => {
      try {
        fetch("/api/products")
          .then((res) => {
            return res.json();
          })
          .then((res) => setData(res))
          .catch((error) => new Error(error));
      } catch (error) {
        console.error("Произошла ошибка:", error);
      }

  }, []);
  console.log(data);

  return (
    <main className="landing">
      <div className="cards">
        {Object.keys(data).length !== 0
          ? data.map((item) => (
              <Card
                key={item.id}
                id={item.id}
                name={item.name}
                price={item.price}
                quant={item.quantity}
                image_url={item.image}
                setCartState={setCartState}
                cartState={cartState}
              />
            ))
          : <Circles color="var(--tg-theme-button-color)" />}
      </div>
      {checkHasNoZero(cartState) ? (
        <MainButton
          text="Перейти к заказу"
          onClick={() => {
            setCart((prev: object) => {
              return { ...prev, ...cartState };
            });
            return navigate("/cart");
          }}
        />
      ) : null}
    </main>
  );
};

export default Landing;
