/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
import Header from "features/components/Header";
import { Fragment, ReactNode, lazy } from "react";
import { Route, Routes } from "react-router-dom";
import { Suspense } from "react";
import { Circles } from "react-loader-spinner";
import "./Loading.scss";

const Landing = lazy(() => import("./Landing"));
const History = lazy(() => import("./History"));
const Cart = lazy(() => import("./Cart"));
const Order = lazy(() => import("./Order"));

const Load = ({ children }: { children: ReactNode }) => {
  return (
    <Suspense
      fallback={
        <Circles color="var(--tg-theme-button-color)" wrapperClass="loading" />
      }
    >
      {children}
    </Suspense>
  );
};

const Routing = () => {
  return (
    <Fragment>
      <Header />
      <Routes>
        <Route path="/" element={<Load children={<Landing />} />} />
        <Route path="/history" element={<Load children={<History />} />} />
        <Route path="/cart" element={<Load children={<Cart />} />} />
        <Route path="/order/:id" element={<Load children={<Order />} />} />
        <Route path="*" element={<Load children={<Landing />} />} />
      </Routes>
    </Fragment>
  );
};

export default Routing;
