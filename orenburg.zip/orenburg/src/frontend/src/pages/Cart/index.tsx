/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
import "./Cart.scss";
import { Context } from "app/contexts";
import { useContext, useEffect, useState } from "react";
import {
  BackButton,
  useShowPopup,
  MainButton,
} from "@vkruglikov/react-telegram-web-app";
import { useNavigate } from "react-router-dom";

const Cart = () => {
  const [userInfo, cart] = useContext(Context);
  const showPopup = useShowPopup();
  const navigate = useNavigate();

  const [selectedOption, setSelectedOption] = useState();
  const [address, setAddress] = useState("");
  const [asd, ASD] = useState();

  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
  };

  return (
    <main className="cart">
      <p className="cart-title">Заказ</p>
      {Object.keys(cart).length !== 0 ? (
        Object.keys(cart).map((id) =>
          cart[id].count !== 0 ? (
            <>
              <div key={id} className="cart-item">
                <div className="item_wrapper">
                  <div className="item-image">
                    <img src={cart[id].image} alt="image alt" />
                  </div>
                  <div className="item-title">
                    <p>
                      {cart[id].name} {cart[id].count} x {cart[id].price}руб.
                    </p>
                  </div>
                </div>
                <div className="price">
                  <p>{cart[id].price * cart[id].count}руб.</p>
                </div>
              </div>
            </>
          ) : null
        )
      ) : (
        <p>Ваш заказ пуст</p>
      )}

      <div className="radiobuttons">
        <p>
          <input
            type="radio"
            name="type"
            value="pickup"
            id="0"
            onChange={handleOptionChange}
          />
          <label htmlFor="0"> самовывоз</label>
        </p>
        <p>
          <input
            type="radio"
            name="type"
            value="delivery"
            id="1"
            onChange={handleOptionChange}
          />
          <label htmlFor="1"> доставка</label>
        </p>
      </div>
      {selectedOption === "delivery" ? (
        <input
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          type="text"
          placeholder="Адрес"
          className="address"
        />
      ) : null}

      <BackButton
        onClick={() => {
          showPopup({
            message: "Вы действительно хотите оменить заказ?",
            buttons: [{ id: "yes", text: "Да" }, { text: "Нет" }],
          }).then((buttonId) => {
            if (buttonId === "yes") navigate("/");
            else return;
          });
        }}
      />
      <button
        text="Оплатить"
        onClick={() => {
          const extractedData = Object.keys(cart).map((product) => {
            const { id, count } = product;
            return { id, amount: count };
          });

          fetch("/api/order/", {
            method: "post",
            headers: {
              "Content-Type": "application/json",
            },
            body: {
              customer_username: userInfo.user.username,
              delivery_address: selectedOption === "pickup" ? null : address,
              products: extractedData,
            },
          });
                      
        }}
      >123</button>
      <MainButton
        text="Оплатить"
        onClick={() => {
            const extractedData = Object.keys(cart).map((product) => {
              const { id, count } = product;
              return { id, amount: count };
            });

            console.log({
              customer_username: userInfo.user.username,
              delivery_address: selectedOption === "pickup" ? null : address,
              products: extractedData,
            })

            fetch("/api/order/", {
              method: "post",
              headers: {
                "Content-Type": "application/json",
              },
              body: {
                customer_username: userInfo.user.username,
                delivery_address: selectedOption === "pickup" ? null : address,
                products: extractedData,
              },
            });
                      
        }}
      />
    </main>
  );
};

export default Cart;
