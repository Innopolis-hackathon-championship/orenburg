/* eslint-disable @typescript-eslint/no-unused-vars */
import { useLocation } from "react-router-dom"
import './Order.scss'

const Order = () => {
  const location = useLocation()
  const data = {
    id: 1423,
    status: 'ready',
    address: '1104 комната',
    start_date: '12.05.2026 22:10',
    amount: '123422',
    products: [{title: 'Булочка', price: 40}],
    code: 1232
  }
  return (
    <main className="order">
      <p className="order-title">Заказ №{data.id}</p>
      <p className="order-status">Статус: {data.status}</p>
      <p className="address">Адрес: {data.address}</p>
      <p className="start_date">Время заказа: {data.start_date}</p>
      <p className="anount">Стимость: {data.amount}</p>
      <p className="products">Продукты: {data.products[0].title}</p>
      <p className="code">Код получения: {data.code}</p>
    </main>
  )
}

export default Order