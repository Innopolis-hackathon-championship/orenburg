import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import mkcert from "vite-plugin-mkcert";
import fs from "fs";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), mkcert()],
  resolve: {
    alias: {
      app: "/src/app/",
      entities: "/src/entities/",
      features: "/src/features/",
      pages: "/src/pages/",
      shared: "/src/shared/",
      widgets: "/src/widgets/",
      public: "/public/",
    },
  },
  server: {
    https: {
      key: fs.readFileSync("./localhost.key"),
      cert: fs.readFileSync("./localhost.crt"),
    },
    port: 3000,
    host: "0.0.0.0",
    proxy: {
      "/api": {
        target: "https://d5dp44phn364v742p8gi.apigw.yandexcloud.net",
        changeOrigin: true,
      },
      "/media": {
        target: "https://d5dp44phn364v742p8gi.apigw.yandexcloud.net/media",
        changeOrigin: true,
      },
    },
  },
});
