import enum


class Role(enum.Enum):
    customer = "customer"
    courier = "courier"
    barmaid = "barmaid"
    admin = "admin"
